#pragma once

namespace AppSecrets
{
    static constexpr char WIFI_SSID[] = "PD24";
    static constexpr char WIFI_PASSWORD[] = "HiesT.Wsagum.";
}
